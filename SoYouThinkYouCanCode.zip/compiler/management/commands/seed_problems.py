import csv
from django.core.management.base import BaseCommand
from compiler.models import Problem

class Command(BaseCommand):
    help = 'Seed the database with problems from a csv file.'

    def handle(self, *args, **kwargs):

        csv_file_path = 'D:\Webdev\Projects\Django\Data\problems.csv'

        with open(csv_file_path, newline='', encoding='utf-8-sig') as csvfile:
            reader = csv.DictReader(csvfile)
            headers = reader.fieldnames
            print("CSV headers: ", headers)

            i = 0
            for row in reader:
                i = i+1

                problem, created = Problem.objects.get_or_create(
                    title = row['problem_name'],
                    defaults = {
                        'description': row['question'],
                        'difficulty': row['difficulty'],
                    }
                )

                if created:
                    self.stdout.write(self.style.SUCCESS(f'Problem "{row["problem_id"]}" created'))

                else:
                    self.stdout.write(self.style.WARNING(f'Problem "{row["problem_id"]}" already exists'))

                if i == 11:
                    break