from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('index/', views.index, name='index'),
    path('problem_set/', views.probelem_set, name='problem_set'),
    path('problems/<int:prob_id>/', views.problems, name='problems'),
    path('problems/<int:prob_id>/run_solution/', views.run_solution, name='run_solution'),
    path('run_solutions2/', views.run_solutions2, name='run_solutions2'),
    path('add_problem/', views.add_problem, name='add_problem'),
    path('edit_problem/<int:prob_id>/', views.edit_problem, name='edit_problem'),
    path('delete_problem/<int:prob_id>/', views.delete_problem, name='delete_problem'),
    path('add_testcase/<int:prob_id>/', views.add_testcase, name='add_testcase'),
]